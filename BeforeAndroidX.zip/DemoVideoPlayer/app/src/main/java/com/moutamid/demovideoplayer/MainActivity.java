package com.moutamid.demovideoplayer;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.jiajunhui.xapp.medialoader.MediaLoader;
import com.jiajunhui.xapp.medialoader.bean.VideoResult;
import com.jiajunhui.xapp.medialoader.callback.OnVideoLoaderCallBack;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = findViewById(R.id.textVieww);

        Toast.makeText(this, "Loading...", Toast.LENGTH_SHORT).show();

        MediaLoader.getLoader().loadVideos(this, new OnVideoLoaderCallBack() {
            @Override
            public void onResult(VideoResult result) {

                result.getItems().get(0).get

                Toast.makeText(MainActivity.this, "done" + result.getTotalSize(), Toast.LENGTH_SHORT).show();
                textView.setText(result.getItems().get(0).getPath() + "");
            }
        });

        Toast.makeText(this, "onCreate() done", Toast.LENGTH_SHORT).show();
    }

}